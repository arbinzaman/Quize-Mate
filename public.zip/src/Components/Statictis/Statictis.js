import React from 'react';

const Statictis = () => {
    return (
        <div>
            <h1>Comming Soon</h1>
        </div>
    );
};

export default Statictis;